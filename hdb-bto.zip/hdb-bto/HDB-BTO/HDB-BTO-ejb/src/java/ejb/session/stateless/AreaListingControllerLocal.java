/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.AreaListing;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author zhiweigoh
 */
@Local
public interface AreaListingControllerLocal {

    public AreaListing createNewAreaListing(AreaListing areaListing);

    public List<AreaListing> retrieveAllAreaListings();

    public int retrieveFirstAreaThreeRoomQuota();

    public int retrieveFirstAreaFourRoomQuota();

    public int retrieveFirstAreaFiveRoomQuota();
    
}
