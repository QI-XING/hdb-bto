/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import entity.Couple;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class CoupleController implements CoupleControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;

    public CoupleController()
    {
        
    }
    
    @Override
    public Couple createNewCouple(Couple couple)
    {
        em.persist(couple);
        em.flush();
        em.refresh(couple);
        return couple;
    }
    
    @Override
    public Boolean isApproved(String nric)
    {
        List<Couple> couples = retrieveAllCouples();
        for(Couple couple: couples)
        {
            if(couple.getApplicant1().getNric().equals(nric) && couple.getHdbVerified() == true && couple.getHdbVerified() == true)
                return true;
        }
        return false;
    }
    
    @Override
    public List<Couple> retrieveAllCouples()
    {
        Query query = em.createQuery("SELECT c FROM Couple c");
        return query.getResultList();
    }
    
    @Override
    public Couple retrieveCouple(Applicant applicant)
    {
        Query query = em.createQuery("SELECT c FROM Couple c WHERE c.applicant1.nric = :inNric");
        query.setParameter("inNric", applicant.getNric());
        return (Couple)query.getSingleResult();
    }
    
    @Override
    public List<Couple> retrieveHDBApproveCouples()
    {
        Query query = em.createQuery("SELECT c FROM Couple c WHERE c.hdbVerified = TRUE AND c.cpfVerified = FALSE");
        return query.getResultList();
    }   
    
    //Added by QX
    @Override
    public List<Couple> retrievePendingVerifyCouples()
    {
        Query query = em.createQuery("SELECT c FROM Couple c WHERE c.cpfVerified = 0");
        return query.getResultList();
    }
    
    @Override
    public List<Couple> retrieveAllVerifiedCouples()
    {
        Query query = em.createQuery("SELECT c FROM Couple c WHERE c.hdbVerified = 1 AND c.cpfVerified = 0");
        return query.getResultList();
    }
    
    @Override
    public Couple retrieveCoupleById(Long coupleId)
    {
        Query query = em.createQuery("SELECT c FROM Couple c WHERE c.coupleId = :inCoupleId");
        query.setParameter("inCoupleId", coupleId);
        return (Couple)query.getSingleResult();
    }
    
    @Override
    public void hdbVerify(Long coupleId)
    {
        Query query = em.createQuery("UPDATE Couple c SET c.hdbVerified = 1 WHERE c.coupleId = :inCoupleId");
        query.setParameter("inCoupleId", coupleId);
        query.executeUpdate();
    }
    
    @Override
    public void administerGrant(Long coupleId, BigDecimal grantAmount)
    {
        Query query = em.createQuery("UPDATE Couple c SET c.cpfVerified = 1 , c.grantAmount = :inGrantAmount WHERE c.coupleId = :inCoupleId");
        query.setParameter("inGrantAmount", grantAmount);
        query.setParameter("inCoupleId", coupleId);
        query.executeUpdate();
    }
}
