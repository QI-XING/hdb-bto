/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import entity.Couple;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author zhiweigoh
 */
@Local
public interface CoupleControllerLocal {

    public Couple createNewCouple(Couple couple);

    public List<Couple> retrieveAllCouples();

    public Boolean isApproved(String nric);

    public Couple retrieveCouple(Applicant applicant);

    public List<Couple> retrieveHDBApproveCouples();

    public void administerGrant(Long coupleId, BigDecimal grantAmount);

    public void hdbVerify(Long coupleId);

    public Couple retrieveCoupleById(Long coupleId);

    public List<Couple> retrieveAllVerifiedCouples();

    public List<Couple> retrievePendingVerifyCouples();
    
}
