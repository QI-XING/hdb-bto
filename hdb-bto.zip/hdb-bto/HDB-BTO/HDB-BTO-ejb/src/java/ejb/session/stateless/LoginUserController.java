/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.LoginUser;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.InvalidLoginCredentialException;
import util.exception.UserNotFoundException;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class LoginUserController implements LoginUserControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;

    public LoginUserController()
    {
        
    }

    @Override
    public LoginUser createNewUser(LoginUser user) {
        
        em.persist(user);
        em.flush();
        em.refresh(user);
        return user;
    }

    @Override
    public LoginUser userLogin(String username, String password) throws InvalidLoginCredentialException
    {
        try
        {
            LoginUser user = retrieveUserByUsername(username);
            
            if(user.getPassword().equals(password))
            {
                return user;
            }
            else
            {
                throw new InvalidLoginCredentialException("IC does not exist or invalid password!");
            }
        }
        catch(UserNotFoundException ex)
        {
            throw new InvalidLoginCredentialException("IC does not exist or invalid password!");
        }
    }

    @Override
    public LoginUser retrieveUserByUsername(String username) throws UserNotFoundException
    {
        Query query = em.createQuery("SELECT u FROM LoginUser u WHERE u.username = :inUser");
        query.setParameter("inUser", username);
        
        try
        {
            return (LoginUser)query.getSingleResult();
        }
        catch(NoResultException | NonUniqueResultException ex)
        {
            throw new UserNotFoundException("IC " + username + " does not exist!");
        }
    }  
}
