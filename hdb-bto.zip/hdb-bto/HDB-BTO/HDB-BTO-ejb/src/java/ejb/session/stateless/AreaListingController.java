/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.AreaListing;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class AreaListingController implements AreaListingControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;
    
    public AreaListingController()
    {
        
    }
    
    @Override
    public AreaListing createNewAreaListing(AreaListing areaListing)
    {
        em.persist(areaListing);
        em.flush();
        em.refresh(areaListing);
        return areaListing;
    }
    
    @Override
    public List<AreaListing> retrieveAllAreaListings()
    {
        Query query = em.createQuery("SELECT al FROM AreaListing al ORDER BY al.area ASC");
        
        return query.getResultList();
    }
    
    @Override
    public int retrieveFirstAreaThreeRoomQuota()
    {
        Query query = em.createQuery("SELECT al.RoomQuota3Room FROM AreaListing al WHERE al.areaListingId = 1");
        return (int)query.getSingleResult();
    }
    
    @Override
    public int retrieveFirstAreaFourRoomQuota()
    {
        Query query = em.createQuery("SELECT al.RoomQuota4Room FROM AreaListing al WHERE al.areaListingId = 1");
        return (int)query.getSingleResult();
    }
    
    @Override
    public int retrieveFirstAreaFiveRoomQuota()
    {
        Query query = em.createQuery("SELECT al.RoomQuota5Room FROM AreaListing al WHERE al.areaListingId = 1");
        return (int)query.getSingleResult();
    }
    
}
