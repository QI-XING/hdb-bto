/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.ResponseProcessingException;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import ws.restful.datamodel.ApplicantRest;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class ApplicantController implements ApplicantControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;
    
    public ApplicantController()
    {
        
    }
    
    @Override
    public Applicant createNewApplicant(Applicant applicant)
    {
        em.persist(applicant);
        em.flush();
        em.refresh(applicant);
        
//        Client client = ClientBuilder.newClient();
//        try{
//            WebTarget target = client.target("http://localhost:3000/api/org.acme.model.Applicant");
//            System.out.println("***********rs status************"+target.getUri());
//            
//            DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
//            String dateOfBirth = df.format(applicant.getDob());
//            
//            BigDecimal s = applicant.getSalary();
//            Double salary = s.doubleValue();
//            
//            ApplicantRest newApplicant = new ApplicantRest(applicant.getNric(), applicant.getName(), applicant.getMobile(), applicant.getEmail(), applicant.getAddress(), applicant.getSex(), dateOfBirth, salary);
//            System.out.println("***********rs status************"+newApplicant.toString());
//
//            Response rs = target.request().post(Entity.json(newApplicant));
//            
//            System.out.println("***********rs status************"+rs.getStatus());
//        }
//        catch(ResponseProcessingException ex){
//            ex.printStackTrace();
//            throw new NotFoundException("Error Occured");
//        }
        
        return applicant;
    }
    
    @Override
    public Applicant dataInitCreate(Applicant applicant)
    {
        em.persist(applicant);
        em.flush();
        em.refresh(applicant);
        return applicant;
    }
    
    @Override
    public Boolean hasApplied(String nric)
    {
        List<Applicant> applicants = retrieveAllApplicant();
        for(Applicant applicant: applicants)
        {
            if(applicant.getNric().equals(nric))
                return true;
        }
        return false;
    }
    
    @Override
    public Applicant retrieveApplicantFromUser(String nric)
    {
        Query query = em.createQuery("SELECT a FROM Applicant a WHERE a.nric = :inNric");
        query.setParameter("inNric", nric);
        return (Applicant)query.getSingleResult();
    }
    
    @Override
    public List<Applicant> retrieveAllApplicant()
    {
        Query query = em.createQuery("SELECT a FROM Applicant a");
        return query.getResultList();
    }
    
    @Override
    public Applicant retrieveApplicantWithId(Long applicantId)
    {
        Applicant applicant = em.find(Applicant.class, applicantId);
        return applicant;
    }
    
}
