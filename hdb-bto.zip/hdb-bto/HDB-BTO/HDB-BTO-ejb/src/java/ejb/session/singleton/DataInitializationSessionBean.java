/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.singleton;

import ejb.session.stateless.ApplicantControllerLocal;
import ejb.session.stateless.AreaListingControllerLocal;
import ejb.session.stateless.CoupleControllerLocal;
import ejb.session.stateless.FlatApplicationControllerLocal;
import ejb.session.stateless.LoginUserControllerLocal;
import entity.Applicant;
import entity.AreaListing;
import entity.Couple;
import entity.FlatApplication;
import entity.LoginUser;
import enumeration.FlatType;
import enumeration.UserStatus;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author zhiweigoh
 */
@Singleton
@LocalBean
@Startup
public class DataInitializationSessionBean {

    @EJB(name = "FlatApplicationControllerLocal")
    private FlatApplicationControllerLocal flatApplicationControllerLocal;

    @EJB(name = "AreaListingControllerLocal")
    private AreaListingControllerLocal areaListingControllerLocal;

    @EJB(name = "CoupleControllerLocal")
    private CoupleControllerLocal coupleControllerLocal;
    
    @EJB(name = "ApplicantControllerLocal")
    private ApplicantControllerLocal applicantControllerLocal;

    @EJB(name = "LoginUserControllerLocal")
    private LoginUserControllerLocal loginUserControllerLocal;
    
    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;
    
    public DataInitializationSessionBean()
    {
    }
    
    @PostConstruct
    public void postConstruct()
    {
        if (em.find(LoginUser.class, 1l) == null) {
            initialiseData();
        }
    }
    
    private void initialiseData()
    { 
        LoginUser user1 = loginUserControllerLocal.createNewUser(new LoginUser("HDB1", "alvinhdb", UserStatus.hdbAdmin));
        LoginUser user2 = loginUserControllerLocal.createNewUser(new LoginUser("HDB2", "benjaminhdb", UserStatus.hdbAdmin));
        LoginUser user3 = loginUserControllerLocal.createNewUser(new LoginUser("HDB3", "charleshdb", UserStatus.hdbAdmin));
        LoginUser user4 = loginUserControllerLocal.createNewUser(new LoginUser("CPF1", "aaroncpf", UserStatus.cpfAdmin));
        LoginUser user5 = loginUserControllerLocal.createNewUser(new LoginUser("CPF2", "bobbycpf", UserStatus.cpfAdmin));
        LoginUser user6 = loginUserControllerLocal.createNewUser(new LoginUser("CPF3", "calvincpf", UserStatus.cpfAdmin));
        LoginUser user7 = loginUserControllerLocal.createNewUser(new LoginUser("S9219331F", "jonathantay", UserStatus.userPanel));
        LoginUser user8 = loginUserControllerLocal.createNewUser(new LoginUser("S8739201G", "kelvinchoo", UserStatus.userPanel));
        LoginUser user9 = loginUserControllerLocal.createNewUser(new LoginUser("S9173916I", "angelalim", UserStatus.userPanel));
        LoginUser user10 = loginUserControllerLocal.createNewUser(new LoginUser("S8836194B", "christinatan", UserStatus.userPanel));
        LoginUser user11 = loginUserControllerLocal.createNewUser(new LoginUser("S8562911G", "matthewgoh", UserStatus.userPanel));
        LoginUser user12 = loginUserControllerLocal.createNewUser(new LoginUser("S8615816F", "alberttan", UserStatus.userPanel));
        LoginUser user13 = loginUserControllerLocal.createNewUser(new LoginUser("S9037144I", "amandang", UserStatus.userPanel));
        LoginUser user14 = loginUserControllerLocal.createNewUser(new LoginUser("S8749827A", "rachelong", UserStatus.userPanel));
//        LoginUser user15 = loginUserControllerLocal.createNewUser(new LoginUser("S8204718F", "marksim", UserStatus.userPanel));
//        LoginUser user16 = loginUserControllerLocal.createNewUser(new LoginUser("S8572017G", "jasmineang", UserStatus.userPanel));
//        LoginUser user17 = loginUserControllerLocal.createNewUser(new LoginUser("S9391840A", "desmondlee", UserStatus.userPanel));
//        LoginUser user18 = loginUserControllerLocal.createNewUser(new LoginUser("S9401840I", "julianalim", UserStatus.userPanel));
//        LoginUser user19 = loginUserControllerLocal.createNewUser(new LoginUser("S8819381E", "evantam", UserStatus.userPanel));
//        LoginUser user20 = loginUserControllerLocal.createNewUser(new LoginUser("S9138101G", "jessicaloo", UserStatus.userPanel));

        SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy");
        try
        {
            Applicant applicant1 = applicantControllerLocal.dataInitCreate(new Applicant("Jonathan Tay", "92835292", "S9219331F", "jontay@gmail.com", "Male", sdf.parse("13-03-1992"), "13 West Coast Drive  08-101 S(120013)", new BigDecimal("3400")));
            Applicant applicant2 = applicantControllerLocal.dataInitCreate(new Applicant("Kelvin Choo", "92036113", "S8739201G", "kelvin@gmail.com", "Male", sdf.parse("28-05-1987"), "582 Tampines Ave 3 03-284 S(478582)", new BigDecimal("2900")));
            Applicant applicant3 = applicantControllerLocal.dataInitCreate(new Applicant("Angela Lim", "82519153", "S9173916I", "angela@gmail.com", "Female", sdf.parse("30-11-1991"), "102 Jurong West Street 41 10-381 S(172102)", new BigDecimal("3800")));
            Applicant applicant4 = applicantControllerLocal.dataInitCreate(new Applicant("Chritina Tan", "94302842", "S8836194B", "christina@gmail.com", "Female", sdf.parse("08-04-1988"), "409 Choa Chu Kang Ave 2 14-217 S(184409)", new BigDecimal("2300")));
            Applicant applicant5 = applicantControllerLocal.dataInitCreate(new Applicant("Matthew Goh", "81049224", "S8562911G", "matthew@gmail.com", "Male", sdf.parse("05-12-1985"), "208 Yishun Ave 7 06-881 S(650208)", new BigDecimal("3100")));
            Applicant applicant6 = applicantControllerLocal.dataInitCreate(new Applicant("Albert Tan", "94727193", "S8615816F", "albert@gmail.com", "Male", sdf.parse("04-11-1986"), "321C Hougang Street 32 07-261 S(749321)", new BigDecimal("3900")));
            Applicant applicant7 = applicantControllerLocal.dataInitCreate(new Applicant("Amanda Ng", "83262938", "S9037144I", "amanda@gmail.com", "Female", sdf.parse("16-06-1990"), "82D Bishan Street 83 08-193 S(846082)", new BigDecimal("1500")));
            Applicant applicant8 = applicantControllerLocal.dataInitCreate(new Applicant("Rachel Ong", "92819472", "S8749827A", "rachel@gmail.com", "Female", sdf.parse("23-03-1987"), "326 Pasir Ris Drive 08-152 S(749326)", new BigDecimal("3000")));
  
            Couple couple1 = coupleControllerLocal.createNewCouple(new Couple(applicant1, applicant3, true, true, new BigDecimal("15000")));
            Couple couple2 = coupleControllerLocal.createNewCouple(new Couple(applicant2, applicant4, true, true, new BigDecimal("35000")));
            Couple couple3 = coupleControllerLocal.createNewCouple(new Couple(applicant5, applicant7, true, true, new BigDecimal("45000")));
            Couple couple4 = coupleControllerLocal.createNewCouple(new Couple(applicant6, applicant8, false, false, null));
            
            AreaListing areaListing1 = areaListingControllerLocal.createNewAreaListing(new AreaListing(1, 156, 103, sdf.parse("13-03-2018"), sdf.parse("30-06-2018"), "Tampines"));
            AreaListing areaListing2 = areaListingControllerLocal.createNewAreaListing(new AreaListing(78, 176, 148, sdf.parse("13-03-2018"), sdf.parse("30-06-2018"), "Hougang"));
            AreaListing areaListing3 = areaListingControllerLocal.createNewAreaListing(new AreaListing(100, 159, 96, sdf.parse("13-03-2018"), sdf.parse("30-06-2018"), "Clementi"));
            
            FlatApplication flatApplication1 = flatApplicationControllerLocal.createNewFlatApplication(new FlatApplication(FlatType.HDB3Room, areaListing1, couple1));
            FlatApplication flatApplication2 = flatApplicationControllerLocal.createNewFlatApplication(new FlatApplication(FlatType.HDB3Room, areaListing1, couple2));
            FlatApplication flatApplication3 = flatApplicationControllerLocal.createNewFlatApplication(new FlatApplication(FlatType.HDB3Room, areaListing1, couple3));
        }
        catch (ParseException ex) {
            Logger.getLogger(DataInitializationSessionBean.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
}
