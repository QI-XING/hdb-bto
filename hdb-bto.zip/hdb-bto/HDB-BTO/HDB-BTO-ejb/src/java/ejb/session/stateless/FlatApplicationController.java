/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import entity.Couple;
import entity.FlatApplication;
import enumeration.FlatType;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class FlatApplicationController implements FlatApplicationControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;

    public FlatApplicationController(){
        
    }
    
    @Override
    public FlatApplication createNewFlatApplication(FlatApplication flatApplication)
    {
        em.persist(flatApplication);
        em.flush();
        em.refresh(flatApplication);
        return flatApplication;
    }
    
    @Override
    public boolean hasApplied(String nric)
    {
        Applicant applicant = retrieveApplicantWithNRIC(nric);
        List<Couple> couples = retrieveAllCouple();
        List<FlatApplication> flatApplications = retrieveAllApplication();

        for(Couple couple: couples)
        {
            if(couple.getApplicant1().equals(applicant))
            {
                for(FlatApplication flatApplication: flatApplications)
                {
                    if(flatApplication.getCouple().equals(couple))
                        return true;
                }
            }
               
        }
        return false;
    }
    
    @Override
    public List<FlatApplication> retrieveThreeRoomFirstArea()
    {
        Query query = em.createQuery("SELECT fa FROM FlatApplication fa WHERE fa.flatType = :inFlatType AND fa.areaListing.areaListingId = 1");
        query.setParameter("inFlatType", FlatType.HDB3Room);
        return query.getResultList();
    }
    
    @Override
    public List<FlatApplication> retrieveFourRoomFirstArea()
    {
        Query query = em.createQuery("SELECT fa FROM FlatApplication fa WHERE fa.flatType = :inFlatType AND fa.areaListing.areaListingId = 1");
        query.setParameter("inFlatType", FlatType.HDB4Room);
        return query.getResultList();
    }
    
    @Override
    public List<FlatApplication> retrieveFiveRoomFirstArea()
    {
        Query query = em.createQuery("SELECT fa FROM FlatApplication fa WHERE fa.flatType = :inFlatType AND fa.areaListing.areaListingId = 1");
        query.setParameter("inFlatType", FlatType.HDB5Room);
        return query.getResultList();
    }
    
    @Override
    public List<FlatApplication> retrieveAllApplication()
    {
        Query query = em.createQuery("SELECT fa FROM FlatApplication fa");
        return query.getResultList();
    }
    
    @Override
    public List<Couple> retrieveAllCouple()
    {
        Query query = em.createQuery("SELECT c from Couple c");
        return query.getResultList();
    }
    
    @Override
    public Applicant retrieveApplicantWithNRIC(String nric)
    {
        Query query = em.createQuery("SELECT a FROM Applicant a WHERE a.nric = :inNric");
        query.setParameter("inNric", nric);
        return (Applicant)query.getSingleResult();
    }
    
    //Added by QX
    @Override
    public String retrieveAddressByCoupleId(Long coupleId)
    {
        Query query = em.createQuery("SELECT fa FROM FlatApplication fa WHERE fa.couple.coupleId = :inCoupleId");
        query.setParameter("inCoupleId", coupleId);
        FlatApplication flatApplication = (FlatApplication)query.getSingleResult();
        return flatApplication.getAreaListing().getArea() + "["+ flatApplication.getFlatType().toString() + "]";
    }
    
}
