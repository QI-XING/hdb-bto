/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import entity.Couple;
import entity.FlatApplication;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author zhiweigoh
 */
@Local
public interface FlatApplicationControllerLocal {


    public FlatApplication createNewFlatApplication(FlatApplication flatApplication);

    public List<FlatApplication> retrieveAllApplication();

    public Applicant retrieveApplicantWithNRIC(String nric);

    public List<Couple> retrieveAllCouple();

    public boolean hasApplied(String nric);

    public String retrieveAddressByCoupleId(Long coupleId);

    public List<FlatApplication> retrieveFiveRoomFirstArea();

    public List<FlatApplication> retrieveFourRoomFirstArea();

    public List<FlatApplication> retrieveThreeRoomFirstArea();
    
}
