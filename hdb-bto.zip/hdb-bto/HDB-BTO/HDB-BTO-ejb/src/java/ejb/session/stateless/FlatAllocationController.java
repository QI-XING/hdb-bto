/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.FlatAllocation;
import enumeration.FlatType;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author zhiweigoh
 */
@Stateless
public class FlatAllocationController implements FlatAllocationControllerLocal {

    @PersistenceContext(unitName = "HDB-BTO-ejbPU")
    private EntityManager em;
    
    public FlatAllocationController(){
    
    }
    
    @Override
    public FlatAllocation allocateFlat(FlatAllocation flatAllocation)
    {
        em.persist(flatAllocation);
        em.flush();
        em.refresh(flatAllocation);
        return flatAllocation;
    }
    
    @Override
    public List<FlatAllocation> retrieveFirstAreaThreeRoom()
    {
        Query query = em.createQuery("SELECT fa FROM FlatAllocation fa WHERE fa.flatType = :inFlatType AND fa.area = :inArea");
        query.setParameter("inFlatType", FlatType.HDB3Room);
        query.setParameter("inArea", "Tampines");
        return query.getResultList();
    }
    
    @Override
    public List<FlatAllocation> retrieveFirstAreaFourRoom()
    {
        Query query = em.createQuery("SELECT fa FROM FlatAllocation fa WHERE fa.flatType = :inFlatType AND fa.area = :inArea");
        query.setParameter("inFlatType", FlatType.HDB4Room);
        query.setParameter("inArea", "Tampines");
        return query.getResultList();
    }
    
    @Override
    public List<FlatAllocation> retrieveFirstAreaFiveRoom()
    {
        Query query = em.createQuery("SELECT fa FROM FlatAllocation fa WHERE fa.flatType = :inFlatType AND fa.area = :inArea");
        query.setParameter("inFlatType", FlatType.HDB5Room);
        query.setParameter("inArea", "Tampines");
        return query.getResultList();
    }
    
    @Override
    public boolean isFlatAllocated()
    {
        if (em.find(FlatAllocation.class, 1l) == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public void deleteAllocation(Long id)
    {
        FlatAllocation toDelete = retrieveAllocationById(id);
        em.remove(toDelete);
    }
    
    @Override
    public FlatAllocation retrieveAllocationById(Long id)
    {
        FlatAllocation flatAllocation = em.find(FlatAllocation.class, id);

        return flatAllocation;
             
    }
}
