/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Applicant;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author zhiweigoh
 */
@Local
public interface ApplicantControllerLocal {

    public Applicant createNewApplicant(Applicant applicant);

    public List<Applicant> retrieveAllApplicant();

    public Boolean hasApplied(String nric);

    public Applicant retrieveApplicantFromUser(String nric);

    public Applicant retrieveApplicantWithId(Long id);

    public Applicant dataInitCreate(Applicant applicant);
    
}
