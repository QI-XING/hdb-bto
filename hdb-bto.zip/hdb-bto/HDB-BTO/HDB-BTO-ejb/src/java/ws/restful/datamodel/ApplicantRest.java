/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.restful.datamodel;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(name = "applicantRest", propOrder = {
    "NRIC",
    "Name",
    "Mobile",
    "Email",
    "CurrAddr",
    "sex",
    "DOB",
    "Salary"
})

public class ApplicantRest{
    private String NRIC;
    private String Name;
    private String Mobile;
    private String Email;
    private String CurrAddr;
    private String sex;
    private String DOB;
    private Double Salary;

    public ApplicantRest() {
    }

    public ApplicantRest(String NRIC, String Name, String Mobile, String Email, String CurrAddr, String sex, String DOB, Double Salary) {
        this.NRIC = NRIC;
        this.Name = Name;
        this.Mobile = Mobile;
        this.Email = Email;
        this.CurrAddr = CurrAddr;
        this.sex = sex;
        this.DOB = DOB;
        this.Salary = Salary;
    }

    /**
     * @return the NRIC
     */
    public String getNRIC() {
        return NRIC;
    }

    /**
     * @param NRIC the NRIC to set
     */
    public void setNRIC(String NRIC) {
        this.NRIC = NRIC;
    }

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * @return the Mobile
     */
    public String getMobile() {
        return Mobile;
    }

    /**
     * @param Mobile the Mobile to set
     */
    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * @return the DOB
     */
    public String getDOB() {
        return DOB;
    }

    /**
     * @param DOB the DOB to set
     */
    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    /**
     * @return the Salary
     */
    public Double getSalary() {
        return Salary;
    }

    /**
     * @param Salary the Salary to set
     */
    public void setSalary(Double Salary) {
        this.Salary = Salary;
    }

    /**
     * @return the CurrAddr
     */
    public String getCurrAddr() {
        return CurrAddr;
    }

    /**
     * @param CurrAddr the CurrAddr to set
     */
    public void setCurrAddr(String CurrAddr) {
        this.CurrAddr = CurrAddr;
    }
    
    
}
