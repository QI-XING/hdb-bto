/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import enumeration.FlatType;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

/**
 *
 * @author qixin
 */
@Entity
public class FlatApplication implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long flatAppId;
    private FlatType flatType;
    @ManyToOne
    private AreaListing areaListing;
    @OneToOne
    private Couple couple;

    public FlatApplication() {
    }

    public FlatApplication(FlatType flatType, AreaListing areaListing, Couple couple) {
        this.flatType = flatType;
        this.areaListing = areaListing;
        this.couple = couple;
    }

    public Long getFlatAppId() {
        return flatAppId;
    }

    public void setFlatAppId(Long flatAppId) {
        this.flatAppId = flatAppId;
    }

    public FlatType getFlatType() {
        return flatType;
    }

    public void setFlatType(FlatType flatType) {
        this.flatType = flatType;
    }

    public AreaListing getAreaListing() {
        return areaListing;
    }

    public void setAreaListing(AreaListing areaListing) {
        this.areaListing = areaListing;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (flatAppId != null ? flatAppId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the flatAppId fields are not set
        if (!(object instanceof FlatApplication)) {
            return false;
        }
        FlatApplication other = (FlatApplication) object;
        if ((this.flatAppId == null && other.flatAppId != null) || (this.flatAppId != null && !this.flatAppId.equals(other.flatAppId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.FlatApplication[ id=" + flatAppId + " ]";
    }

    /**
     * @return the couple
     */
    public Couple getCouple() {
        return couple;
    }

    /**
     * @param couple the couple to set
     */
    public void setCouple(Couple couple) {
        this.couple = couple;
    }
    
}
