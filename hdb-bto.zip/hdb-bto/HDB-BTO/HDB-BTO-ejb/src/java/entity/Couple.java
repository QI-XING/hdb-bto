/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 *
 * @author qixin
 */
@Entity
public class Couple implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long coupleId;
    @OneToOne
    private Applicant applicant1;
    @OneToOne
    private Applicant applicant2;
    private Boolean hdbVerified;
    private Boolean cpfVerified;
    @Column(nullable=true)
    private BigDecimal grantAmount;

    public Couple() {
    }

    public Couple(Applicant applicant1, Applicant applicant2, Boolean hdbVerified, Boolean cpfVerified, BigDecimal grantAmount) {
        this.applicant1 = applicant1;
        this.applicant2 = applicant2;
        this.hdbVerified = hdbVerified;
        this.cpfVerified = cpfVerified;
        this.grantAmount = grantAmount;
    }
    
    public BigDecimal getGrantAmount(){
        return grantAmount;
    }
    
    public void setGrantAmount(BigDecimal grantAmount){
        this.grantAmount = grantAmount;
    }
    
    public Long getCoupleId() {
        return coupleId;
    }

    public void setCoupleId(Long coupleId) {
        this.coupleId = coupleId;
    }

    public Applicant getApplicant1() {
        return applicant1;
    }

    public void setApplicant1(Applicant applicant1) {
        this.applicant1 = applicant1;
    }

    public Applicant getApplicant2() {
        return applicant2;
    }

    public void setApplicant2(Applicant applicant2) {
        this.applicant2 = applicant2;
    }

    public Boolean getHdbVerified() {
        return hdbVerified;
    }

    public void setHdbVerified(Boolean hdbVerified) {
        this.hdbVerified = hdbVerified;
    }

    public Boolean getCpfVerified() {
        return cpfVerified;
    }

    public void setCpfVerified(Boolean cpfVerified) {
        this.cpfVerified = cpfVerified;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (coupleId != null ? coupleId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the coupleId fields are not set
        if (!(object instanceof Couple)) {
            return false;
        }
        Couple other = (Couple) object;
        if ((this.coupleId == null && other.coupleId != null) || (this.coupleId != null && !this.coupleId.equals(other.coupleId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Couple[ id=" + coupleId + " ]";
    }
    
}
