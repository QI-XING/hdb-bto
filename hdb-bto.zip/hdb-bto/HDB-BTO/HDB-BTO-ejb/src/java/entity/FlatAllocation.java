/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import enumeration.FlatType;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 *
 * @author zhiweigoh
 */
@Entity
public class FlatAllocation implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private FlatType flatType;
    @OneToOne
    private Couple couple;
    private String address;
    private String area;
    
    public FlatAllocation() {
        
    }

    public FlatAllocation(FlatType flatType, Couple couple, String address, String area) {
        this.flatType = flatType;
        this.couple = couple;
        this.address = address;
        this.area = area;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FlatAllocation)) {
            return false;
        }
        FlatAllocation other = (FlatAllocation) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.FlatAllocation[ id=" + id + " ]";
    }

    /**
     * @return the flatType
     */
    public FlatType getFlatType() {
        return flatType;
    }

    /**
     * @param flatType the flatType to set
     */
    public void setFlatType(FlatType flatType) {
        this.flatType = flatType;
    }

    /**
     * @return the couple
     */
    public Couple getCouple() {
        return couple;
    }

    /**
     * @param couple the couple to set
     */
    public void setCouple(Couple couple) {
        this.couple = couple;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the area
     */
    public String getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(String area) {
        this.area = area;
    }
    
}
