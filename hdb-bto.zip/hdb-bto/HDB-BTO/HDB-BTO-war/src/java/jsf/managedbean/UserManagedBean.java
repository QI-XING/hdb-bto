/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.LoginUserControllerLocal;
import entity.LoginUser;
import enumeration.UserStatus;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import org.primefaces.event.FlowEvent;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class UserManagedBean implements Serializable {

    @EJB
    private LoginUserControllerLocal loginUserControllerLocal;
    private LoginUser user;
    
    public UserManagedBean() {
        user = new LoginUser();
    }
    
    public void registerUser(ActionEvent action)
    {   
        user.setStatus(UserStatus.userPanel);
        LoginUser lu = loginUserControllerLocal.createNewUser(user);
        user = new LoginUser();
        
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "You have successfully registered for a account!", null));
    }

    /**
     * @return the user
     */
    public LoginUser getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(LoginUser user) {
        this.user = user;
    }
}
