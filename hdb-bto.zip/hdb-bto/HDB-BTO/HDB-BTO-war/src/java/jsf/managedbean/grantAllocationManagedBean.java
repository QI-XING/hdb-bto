/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.CoupleControllerLocal;
import ejb.session.stateless.FlatApplicationControllerLocal;
import entity.Couple;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import org.primefaces.context.RequestContext;


@Named
@ViewScoped
public class grantAllocationManagedBean implements Serializable {

    @EJB
    private FlatApplicationControllerLocal flatApplicationControllerLocal;

    @EJB
    private CoupleControllerLocal coupleControllerLocal;
    
    private Couple selectedCouple;
    
    private Long coupleId;
            
    public grantAllocationManagedBean() {
    }

    public Couple getSelectedCouple() {
        return selectedCouple;
    }

    public void setSelectedCouple(Couple selectedCouple) {
        this.selectedCouple = selectedCouple;
    }

    public Long getCoupleId() {
        return coupleId;
    }

    public void setCoupleId(Long coupleId) {
        this.coupleId = coupleId;
    }
    
    public List<Couple> retrieveAllVerifiedCouples(){
        List<Couple> couples = coupleControllerLocal.retrieveAllVerifiedCouples();
        return couples;
    }
    
    public void allocateGrant(ActionEvent actionEvent) {
        addMessage("Grant amount has been allocated.");
    }
    
    public void addMessage(String summary) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null);
        FacesContext.getCurrentInstance().addMessage(null, message);
        RequestContext.getCurrentInstance().update("grantTable");
    }
    
    public BigDecimal combineSalary(Long coupleId) {
        Couple couple = coupleControllerLocal.retrieveCoupleById(coupleId);
        return couple.getApplicant1().getSalary().add(couple.getApplicant2().getSalary());
    }
    
    public BigDecimal assignGrant(Long coupleId) {
        Couple couple = coupleControllerLocal.retrieveCoupleById(coupleId);
        BigDecimal combinedSalary = couple.getApplicant1().getSalary().add(couple.getApplicant2().getSalary());
        BigDecimal grantAmount = new BigDecimal(0);
        if(combinedSalary.compareTo(new BigDecimal(1500)) <= 0) {
            grantAmount = new BigDecimal(80000);
        }
        if(combinedSalary.compareTo(new BigDecimal(1500)) > 0 && combinedSalary.compareTo(new BigDecimal(2000)) <= 0) {
            grantAmount = new BigDecimal(75000);
        }
        if(combinedSalary.compareTo(new BigDecimal(2000)) > 0 && combinedSalary.compareTo(new BigDecimal(2500)) <= 0) {
            grantAmount = new BigDecimal(70000);
        }
        if(combinedSalary.compareTo(new BigDecimal(2500)) > 0 && combinedSalary.compareTo(new BigDecimal(3000)) <= 0) {
            grantAmount = new BigDecimal(65000);
        }
        if(combinedSalary.compareTo(new BigDecimal(3000)) > 0 && combinedSalary.compareTo(new BigDecimal(3500)) <= 0) {
            grantAmount = new BigDecimal(60000);
        }
        if(combinedSalary.compareTo(new BigDecimal(3500)) > 0 && combinedSalary.compareTo(new BigDecimal(4000)) <= 0) {
            grantAmount = new BigDecimal(50000);
        }
        if(combinedSalary.compareTo(new BigDecimal(4000)) > 0 && combinedSalary.compareTo(new BigDecimal(4500)) <= 0) {
            grantAmount = new BigDecimal(45000);
        }
        if(combinedSalary.compareTo(new BigDecimal(4500)) > 0 && combinedSalary.compareTo(new BigDecimal(5000)) <= 0) {
            grantAmount = new BigDecimal(40000);
        }
        if(combinedSalary.compareTo(new BigDecimal(5000)) > 0 && combinedSalary.compareTo(new BigDecimal(5500)) <= 0) {
            grantAmount = new BigDecimal(35000);
        }
        if(combinedSalary.compareTo(new BigDecimal(5500)) > 0 && combinedSalary.compareTo(new BigDecimal(6000)) <= 0) {
            grantAmount = new BigDecimal(30000);
        }
        if(combinedSalary.compareTo(new BigDecimal(6000)) > 0 && combinedSalary.compareTo(new BigDecimal(6500)) <= 0) {
            grantAmount = new BigDecimal(25000);
        }
        if(combinedSalary.compareTo(new BigDecimal(6500)) > 0 && combinedSalary.compareTo(new BigDecimal(7000)) <= 0) {
            grantAmount = new BigDecimal(20000);
        }
        if(combinedSalary.compareTo(new BigDecimal(7000)) > 0 && combinedSalary.compareTo(new BigDecimal(7500)) <= 0) {
            grantAmount = new BigDecimal(15000);
        }
        if(combinedSalary.compareTo(new BigDecimal(7500)) > 0 && combinedSalary.compareTo(new BigDecimal(8000)) <= 0) {
            grantAmount = new BigDecimal(10000);
        }
        if(combinedSalary.compareTo(new BigDecimal(8000)) > 0 && combinedSalary.compareTo(new BigDecimal(8500)) <= 0) {
            grantAmount = new BigDecimal(5000);
        }
        return grantAmount;
    }
    
    public void setGrant(Long coupleId, BigDecimal grantAmt) {
        coupleControllerLocal.administerGrant(coupleId, grantAmt);
        RequestContext.getCurrentInstance().update("grantTable:");
    }
    
    public String getFlatAddress(Long coupleId) {
        return flatApplicationControllerLocal.retrieveAddressByCoupleId(coupleId);
    }
}
