/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.ApplicantControllerLocal;
import ejb.session.stateless.CoupleControllerLocal;
import ejb.session.stateless.FlatApplicationControllerLocal;
import entity.Applicant;
import entity.FlatApplication;
import enumeration.FlatType;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class FlatApplicationManagedBean implements Serializable {

    @EJB
    private ApplicantControllerLocal applicantControllerLocal;

    @EJB
    private CoupleControllerLocal coupleControllerLocal;

    @EJB
    private FlatApplicationControllerLocal flatApplicationControllerLocal;
    
    private FlatApplication application;
    
    /**
     * Creates a new instance of FlatApplicationManagedBean
     */
    public FlatApplicationManagedBean() {
        application = new FlatApplication();
    }
        
    public void submitFlatApplication(ActionEvent event)
    {
        Applicant applicant = applicantControllerLocal.retrieveApplicantFromUser((String)event.getComponent().getAttributes().get("mainApplicant")); 
        application.setCouple(coupleControllerLocal.retrieveCouple(applicant));
        FlatApplication fa = flatApplicationControllerLocal.createNewFlatApplication(application);
       // movieEntities.add(me);
        application = new FlatApplication();

        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "You have successfully submitted an application for a flat", null));
    }
    
    public boolean hasApplied(String nric)
    {
        return flatApplicationControllerLocal.hasApplied(nric);
    }

    public FlatType[] getFlatTypes(){
        return FlatType.values();
    }
    
    /**
     * @return the application
     */
    public FlatApplication getApplication() {
        return application;
    }

    /**
     * @param application the application to set
     */
    public void setApplication(FlatApplication application) {
        this.application = application;
    }    
}
