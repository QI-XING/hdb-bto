/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.AreaListingControllerLocal;
import entity.AreaListing;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class AreaListingManagedBean implements Serializable{

    @EJB
    private AreaListingControllerLocal areaListingControllerLocal;

    private List<AreaListing> areaListings;
    private List<SelectItem> selectArea;
    
    public AreaListingManagedBean() {
        areaListings = new ArrayList<>();
        selectArea = new ArrayList<>();
    }
    
    @PostConstruct
    public void postConstruct()
    {
        areaListings = areaListingControllerLocal.retrieveAllAreaListings();
        
        for(AreaListing areaListing:areaListings)
        {
            selectArea.add(new SelectItem(areaListing, areaListing.getArea()));
        }
        
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("AreaListingConverter.areaListings", areaListings);
    }

    @PreDestroy
    public void preDestroy()
    {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("AreaListingConverter.areaListings", null);
    }
    
    
    
    /**
     * @return the areaListings
     */
    public List<AreaListing> getAreaListings() {
        return areaListings;
    }

    /**
     * @param areaListings the areaListing to set
     */
    public void setAreaListing(List<AreaListing> areaListings) {
        this.areaListings = areaListings;
    }    

    /**
     * @return the selectArea
     */
    public List<SelectItem> getSelectArea() {
        return selectArea;
    }

    /**
     * @param selectArea the selectArea to set
     */
    public void setSelectArea(List<SelectItem> selectArea) {
        this.selectArea = selectArea;
    }
}
