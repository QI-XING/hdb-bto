/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.ApplicantControllerLocal;
import ejb.session.stateless.CoupleControllerLocal;
import entity.Applicant;
import entity.Couple;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class CoupleManagedBean implements Serializable {

    @EJB
    private ApplicantControllerLocal applicantControllerLocal;

    @EJB
    private CoupleControllerLocal coupleControllerLocal;
    
    

    private List<Couple> couples;
    private Couple selectedCoupleToVerify;
    
    /**
     * Creates a new instance of CoupleManagedBean
     */
    public CoupleManagedBean() {
        couples = new ArrayList<>();
    }
    
    @PostConstruct
    public void postConstruct()
    {
        couples = coupleControllerLocal.retrieveHDBApproveCouples();
    }
    
    public BigDecimal countGrant(Couple couple) {
        BigDecimal applicantSalary = couple.getApplicant1().getSalary();
        BigDecimal coApplicantSalary = couple.getApplicant2().getSalary();
        BigDecimal totalSalary = applicantSalary.add(coApplicantSalary);
        BigDecimal grantAmount;
        
        
        if(totalSalary.compareTo(new BigDecimal(1501)) == -1)
            grantAmount = new BigDecimal(80000);
            
        else if(totalSalary.compareTo(new BigDecimal(2001)) == -1)
            grantAmount = new BigDecimal(75000);
        
        else if(totalSalary.compareTo(new BigDecimal(2501)) == -1)
            grantAmount = new BigDecimal(70000);
        
        else if(totalSalary.compareTo(new BigDecimal(3001)) == -1)
            grantAmount = new BigDecimal(65000);
        
        else if(totalSalary.compareTo(new BigDecimal(3501)) == -1)
            grantAmount = new BigDecimal(60000);
        
        else if(totalSalary.compareTo(new BigDecimal(4001)) == -1)
            grantAmount = new BigDecimal(55000);
        
        else if(totalSalary.compareTo(new BigDecimal(4501)) == -1)
            grantAmount = new BigDecimal(50000);
        
        else if(totalSalary.compareTo(new BigDecimal(5001)) == -1)
            grantAmount = new BigDecimal(45000);
        
        else if(totalSalary.compareTo(new BigDecimal(5501)) == -1)
            grantAmount = new BigDecimal(35000);
        
        else if(totalSalary.compareTo(new BigDecimal(6001)) == -1)
            grantAmount = new BigDecimal(30000);
        
        else if(totalSalary.compareTo(new BigDecimal(6501)) == -1)
            grantAmount = new BigDecimal(25000);
        
        else if(totalSalary.compareTo(new BigDecimal(7001)) == -1)
            grantAmount = new BigDecimal(20000);
        
        else if(totalSalary.compareTo(new BigDecimal(7501)) == -1)
            grantAmount = new BigDecimal(15000);
        
        else if(totalSalary.compareTo(new BigDecimal(8001)) == -1)
            grantAmount = new BigDecimal(10000);
        
        else if(totalSalary.compareTo(new BigDecimal(8501)) == -1)
            grantAmount = new BigDecimal(5000);
        
        else
            grantAmount = BigDecimal.ZERO;
        
        return grantAmount;
    }

    /**
     * @return the couples
     */
    public List<Couple> getCouples() {
        return couples;
    }

    /**
     * @param couples the couples to set
     */
    public void setCouples(List<Couple> couples) {
        this.couples = couples;
    }

    /**
     * @return the selectedCoupleToVerify
     */
    public Couple getSelectedCoupleToVerify() {
        return selectedCoupleToVerify;
    }

    /**
     * @param selectedCoupleToVerify the selectedCoupleToVerify to set
     */
    public void setSelectedCoupleToVerify(Couple selectedCoupleToVerify) {
        this.selectedCoupleToVerify = selectedCoupleToVerify;
    }
}
