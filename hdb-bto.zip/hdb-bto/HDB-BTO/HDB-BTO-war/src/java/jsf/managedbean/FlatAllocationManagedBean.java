/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.AreaListingControllerLocal;
import ejb.session.stateless.FlatAllocationControllerLocal;
import ejb.session.stateless.FlatApplicationControllerLocal;
import entity.FlatAllocation;
import entity.FlatApplication;
import enumeration.FlatType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.ejb.EJB;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class FlatAllocationManagedBean implements Serializable {

    @EJB
    private AreaListingControllerLocal areaListingControllerLocal;

    @EJB
    private FlatApplicationControllerLocal flatApplicationControllerLocal;

    @EJB
    private FlatAllocationControllerLocal flatAllocationControllerLocal;
    
    private List<FlatApplication> threeRoomFirstArea;
    private List<FlatApplication> fourRoomFirstArea;
    private List<FlatApplication> fiveRoomFirstArea;
    
    private FlatAllocation allocation;

    /**
     * Creates a new instance of FlatAllocationManagedBean
     */
    public FlatAllocationManagedBean() {
        threeRoomFirstArea = new ArrayList<>();
        fourRoomFirstArea = new ArrayList<>();
        fiveRoomFirstArea = new ArrayList<>();
        allocation = new FlatAllocation();   
    }
    
    public boolean ifAllocated()
    {
        return flatAllocationControllerLocal.isFlatAllocated();
    }
    
    public void allocateFlat(ActionEvent event){
        threeRoomFirstArea = flatApplicationControllerLocal.retrieveThreeRoomFirstArea();
        fourRoomFirstArea = flatApplicationControllerLocal.retrieveFourRoomFirstArea();
        fiveRoomFirstArea = flatApplicationControllerLocal.retrieveFiveRoomFirstArea();

        for(int i = 0; i < threeRoomFirstArea.size(); i++)
        {
            allocation.setAddress("Block 636A Tampines North Drive 2");
            allocation.setArea("Tampines");
            allocation.setCouple(threeRoomFirstArea.get(i).getCouple());
            allocation.setFlatType(FlatType.HDB3Room);
            flatAllocationControllerLocal.allocateFlat(allocation);
            allocation = new FlatAllocation();
        }
        
        for(int i = 0; i < fourRoomFirstArea.size(); i++)
        {
            allocation.setAddress("Block 637A Tampines North Drive 2");
            allocation.setArea("Tampines");
            allocation.setCouple(fourRoomFirstArea.get(i).getCouple());
            allocation.setFlatType(FlatType.HDB4Room);
            flatAllocationControllerLocal.allocateFlat(allocation);
            allocation = new FlatAllocation();
        }
        
        for(int i = 0; i < fiveRoomFirstArea.size(); i++)
        {
            allocation.setAddress("Block 638A Tampines North Drive 2");
            allocation.setArea("Tampines");
            allocation.setCouple(fiveRoomFirstArea.get(i).getCouple());
            allocation.setFlatType(FlatType.HDB5Room);
            flatAllocationControllerLocal.allocateFlat(allocation);
            allocation = new FlatAllocation();
        }
        
        //if application is more than quota, have to randomly remove a few
        if(threeRoomFirstArea.size() > areaListingControllerLocal.retrieveFirstAreaThreeRoomQuota())
        {
            Random generator = new Random();
            for(int i = flatAllocationControllerLocal.retrieveFirstAreaThreeRoom().size(); i > areaListingControllerLocal.retrieveFirstAreaThreeRoomQuota(); i--)
            {
                if(!flatAllocationControllerLocal.retrieveFirstAreaThreeRoom().isEmpty())
                {
                    int j = generator.nextInt(i);
                    flatAllocationControllerLocal.deleteAllocation(flatAllocationControllerLocal.retrieveFirstAreaThreeRoom().get(j).getId());  
                }
            }
        }
        
        if(fourRoomFirstArea.size() > areaListingControllerLocal.retrieveFirstAreaFourRoomQuota())
        {
            Random generator = new Random();
            for(int i = flatAllocationControllerLocal.retrieveFirstAreaFourRoom().size(); i > areaListingControllerLocal.retrieveFirstAreaFourRoomQuota(); i--)
            {
                if(!flatAllocationControllerLocal.retrieveFirstAreaFourRoom().isEmpty())
                {
                    int j = generator.nextInt(i);
                    flatAllocationControllerLocal.deleteAllocation(flatAllocationControllerLocal.retrieveFirstAreaFourRoom().get(j).getId());  
                }
            }
            
        }
        
        if(fiveRoomFirstArea.size() > areaListingControllerLocal.retrieveFirstAreaFiveRoomQuota())
        {
            Random generator = new Random();
            for(int i = flatAllocationControllerLocal.retrieveFirstAreaFiveRoom().size(); i > areaListingControllerLocal.retrieveFirstAreaFiveRoomQuota(); i--)
            {
                if(!flatAllocationControllerLocal.retrieveFirstAreaFiveRoom().isEmpty())
                {
                    int j = generator.nextInt(i);
                    flatAllocationControllerLocal.deleteAllocation(flatAllocationControllerLocal.retrieveFirstAreaFiveRoom().get(j).getId());  
                }
            }
        }
    }

    /**
     * @return the threeRoomFirstArea
     */
    public List<FlatApplication> getThreeRoomFirstArea() {
        return threeRoomFirstArea;
    }

    /**
     * @param threeRoomFirstArea the threeRoomFirstArea to set
     */
    public void setThreeRoomFirstArea(List<FlatApplication> threeRoomFirstArea) {
        this.threeRoomFirstArea = threeRoomFirstArea;
    }

    /**
     * @return the fourRoomFirstArea
     */
    public List<FlatApplication> getFourRoomFirstArea() {
        return fourRoomFirstArea;
    }

    /**
     * @param fourRoomFirstArea the fourRoomFirstArea to set
     */
    public void setFourRoomFirstArea(List<FlatApplication> fourRoomFirstArea) {
        this.fourRoomFirstArea = fourRoomFirstArea;
    }

    /**
     * @return the fiveRoomFirstArea
     */
    public List<FlatApplication> getFiveRoomFirstArea() {
        return fiveRoomFirstArea;
    }

    /**
     * @param fiveRoomFirstArea the fiveRoomFirstArea to set
     */
    public void setFiveRoomFirstArea(List<FlatApplication> fiveRoomFirstArea) {
        this.fiveRoomFirstArea = fiveRoomFirstArea;
    }

    /**
     * @return the allocation
     */
    public FlatAllocation getAllocation() {
        return allocation;
    }

    /**
     * @param allocation the allocation to set
     */
    public void setAllocation(FlatAllocation allocation) {
        this.allocation = allocation;
    }
            
    
}
