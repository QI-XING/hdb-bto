/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.CoupleControllerLocal;
import entity.Couple;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import org.primefaces.context.RequestContext;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class HDBAdminIndexManagedBean implements Serializable{

    @EJB
    private CoupleControllerLocal coupleControllerLocal;

    private Long coupleId;
    
    private Couple couple;
    
    public HDBAdminIndexManagedBean() {
    }
    
    public List<Couple> retrievePendingVerifyCouples(){
        List<Couple> couples = coupleControllerLocal.retrievePendingVerifyCouples();
        return couples;
    }

    public Long getCoupleId() {
        return coupleId;
    }

    public void setCoupleId(Long coupleId) {
        this.coupleId = coupleId;
    }
    
    public Couple getCouple() {
        return couple;
    }

    public void setCouple(Couple couple) {
        this.couple = couple;
    }

    public void verify(ActionEvent actionEvent) {
        addMessage("Couple Application has been verified.");
    }
    
    public void update(ActionEvent actionEvent) {
        addMessage("Couple Application has been updated.");
    }
    
    public void addMessage(String summary) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null);
        FacesContext.getCurrentInstance().addMessage(null, message);
        RequestContext.getCurrentInstance().update("coupleTable");
    }
    
    public void hdbVerify() {
        coupleControllerLocal.hdbVerify(coupleId);
    }
    
    //Perform update
    public void updateSalary() {
        System.out.println(couple.getApplicant1().getSalary());
        System.out.println(couple.getApplicant2().getSalary());
    }    
}

