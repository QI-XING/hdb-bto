/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.managedbean;

import ejb.session.stateless.ApplicantControllerLocal;
import ejb.session.stateless.CoupleControllerLocal;
import entity.Applicant;
import entity.Couple;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import org.primefaces.event.FlowEvent;

/**
 *
 * @author zhiweigoh
 */
@Named
@ViewScoped
public class ApplicantManagedBean implements Serializable {

    @EJB
    private CoupleControllerLocal coupleControllerLocal;

    @EJB
    private ApplicantControllerLocal applicantControllerLocal;

    private Applicant mainApplicant;
    private Applicant coApplicant;
    private Couple couple;
    private List<Applicant> applicants;
    private List<Couple> couples;
    private boolean skip;

    /**
     * Creates a new instance of ApplicationManagedBean
     */
    public ApplicantManagedBean() {
        mainApplicant = new Applicant();
        coApplicant = new Applicant();
        couple = new Couple();
        applicants = new ArrayList<>();
        couples = new ArrayList<>();
    }
    
    public void createApplicant(ActionEvent action)
    {   
        Applicant ma = applicantControllerLocal.createNewApplicant(mainApplicant);
        applicants.add(ma);
        
        Applicant ca = applicantControllerLocal.createNewApplicant(coApplicant);
        applicants.add(ca);
        
        couple.setApplicant1(mainApplicant);
        couple.setApplicant2(coApplicant);
        couple.setCpfVerified(Boolean.FALSE);
        couple.setHdbVerified(Boolean.FALSE);
        couple.setGrantAmount(null);
        Couple c = coupleControllerLocal.createNewCouple(couple);
        couples.add(c);
        
        couple = new Couple();
        mainApplicant = new Applicant();
        coApplicant = new Applicant();
        
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "You have successfully submmited a application!", null));
    }
    
    public boolean hasApplied(String nric)
    {
        return applicantControllerLocal.hasApplied(nric);
    }
    
    public boolean isVerified(String nric)
    {
        return coupleControllerLocal.isApproved(nric);
    }
    
    public String onFlowProcess(FlowEvent event) {
        if(skip) {
            skip = false;   //reset in case user goes back
            return "confirm";
        }
        else {
            return event.getNewStep();
        }
    }

    /**
     * @return the mainApplicant
     */
    public Applicant getMainApplicant() {
        return mainApplicant;
    }

    /**
     * @param mainApplicant the mainApplicant to set
     */
    public void setMainApplicant(Applicant mainApplicant) {
        this.mainApplicant = mainApplicant;
    }

    /**
     * @return the coApplicant
     */
    public Applicant getCoApplicant() {
        return coApplicant;
    }

    /**
     * @param coApplicant the coApplicant to set
     */
    public void setCoApplicant(Applicant coApplicant) {
        this.coApplicant = coApplicant;
    }

    /**
     * @return the couple
     */
    public Couple getCouple() {
        return couple;
    }

    /**
     * @param couple the couple to set
     */
    public void setCouple(Couple couple) {
        this.couple = couple;
    }

    /**
     * @return the applicants
     */
    public List<Applicant> getApplicants() {
        return applicants;
    }

    /**
     * @param applicants the applicants to set
     */
    public void setApplicants(List<Applicant> applicants) {
        this.applicants = applicants;
    }

    /**
     * @return the couples
     */
    public List<Couple> getCouples() {
        return couples;
    }

    /**
     * @param couples the couples to set
     */
    public void setCouples(List<Couple> couples) {
        this.couples = couples;
    }
    
}
